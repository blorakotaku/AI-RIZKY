const fs = require('fs')

//settings bot
global.owner = "62895420886464"
global.namaowner = "RapliCreatorsXtrvln"
global.reply = "https://j.top4top.io/p_3334tid4e0.jpg"
global.status = true
global.prefa = ["", "!", ".", ",", "🐤", "🗿"]; //not change!!

//mess
global.mess = {
    owner: "no, this is for owners only",
    group: "this is for groups only",
    private: "this is specifically for private chat",
    murbug: "for only user murbug.."
}

// settings payment
global.dana = "62895420886464"
global.ovo = "Gak Ada"
global.gopay = "62895420886464"

global.image = {
qris: "-"
}
//nama seticker
global.packname = '𝗫𝘁𝗿𝘃𝗹𝗻 𝗪𝗶𝘁𝗵 𝗬𝗼𝘂!'
global.author = 'Made Whit RapliMods'

//End Settings

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
